package lab5.people;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;
import java.util.stream.Collectors;

public class PeopleGrouper {

    public static Map<Integer, List<String>> groupPeopleByNumber(File file) throws FileNotFoundException {
        Scanner scanner = new Scanner(file);
        Map<Integer, List<String>> map = new HashMap<>();

        while (scanner.hasNextLine()) {
            String line = scanner.nextLine().trim();
            if (!line.contains(":")) continue;

            String[] parts = line.split(":");
            String name = parts[0].trim();
            if (name.isEmpty()) continue;

            name = name.substring(0, 1).toUpperCase() + name.substring(1).toLowerCase();

            if (parts.length < 2 || parts[1].trim().isEmpty()) continue;
            try {
                int number = Integer.parseInt(parts[1].trim());
                map.computeIfAbsent(number, k -> new ArrayList<>()).add(name);
            } catch (NumberFormatException ignored) {}
        }
        scanner.close();

        return map.entrySet().stream()
                .sorted(Map.Entry.comparingByKey())
                .collect(Collectors.toMap(
                        Map.Entry::getKey,
                        e -> e.getValue().stream().sorted().toList(),
                        (a, b) -> a,
                        LinkedHashMap::new
                ));
    }
}
