package lab5;

import lab5.fraction.*;
import lab5.cat.*;
import lab5.collections.*;
import lab5.sourcream.*;
import lab5.text.*;
import lab5.geometry.*;
import lab5.people.*;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Главный класс лабораторной работы №5
 * Демонстрирует выполнение всех заданий с пользовательским вводом и валидацией.
 */
public class Main {

    private static final Scanner SCANNER = new Scanner(System.in);

    public static void main(String[] args) {
        while (true) {
            System.out.println("\n=== Лабораторная работа №5 ===");
            System.out.println("1 - Дроби (интерфейсы и кэширование)");
            System.out.println("2 - Кот и количество мяуканий");
            System.out.println("3 - Список (удаление подряд идущих одинаковых элементов)");
            System.out.println("4 - Сметана (минимальные цены по жирности)");
            System.out.println("5 - Текст (поиск цифр в файле)");
            System.out.println("6 - Очередь (поиск одинаковых подряд элементов)");
            System.out.println("7 - Геометрия (ломаная по точкам)");
            System.out.println("8 - Люди (группировка по номеру)");
            System.out.println("0 - Выход");
            System.out.print("Выберите пункт меню: ");

            int choice = readInt();
            switch (choice) {
                case 1 -> runFractionTask();
                case 2 -> runCatTask();
                case 3 -> runListTask();
                case 4 -> runSourCreamTask();
                case 5 -> runDigitFinderTask();
                case 6 -> runQueueTask();
                case 7 -> runGeometryTask();
                case 8 -> runPeopleTask();
                case 0 -> {
                    System.out.println("Выход из программы...");
                    return;
                }
                default -> System.out.println("Некорректный выбор, попробуйте снова.");
            }
        }
    }

    // === Задание 1: Дроби ===
    private static void runFractionTask() {
        System.out.println("\n--- Задание 1: Дроби ---");
        try {
            System.out.print("Введите числитель: ");
            int numerator = readInt();
            System.out.print("Введите знаменатель (≠ 0): ");
            int denominator = readNonZeroInt();

            Fraction fraction = new Fraction(numerator, denominator);

            System.out.println("Дробь: " + fraction);
            System.out.println("Вещественное значение: " + fraction.getRealValue());

            System.out.println("Введите новый числитель:");
            fraction.setNumerator(readInt());
            System.out.println("Введите новый знаменатель (≠ 0):");
            fraction.setDenominator(readNonZeroInt());

            System.out.println("Обновлённая дробь: " + fraction);
            System.out.println("Новое вещественное значение: " + fraction.getRealValue());
        } catch (Exception e) {
            System.out.println("Ошибка: " + e.getMessage());
        }
    }

    // === Задание 2: Кот ===
    private static void runCatTask() {
        System.out.println("\n--- Задание 2: Коты ---");
        System.out.print("Введите имя кота: ");
        String name = SCANNER.next();
        Cat cat = new Cat(name);
        Meowable[] meowers = {cat};

        System.out.println("Передаём кота в метод MeowUtils.makeAllMeow...");
        MeowUtils.makeAllMeow(meowers);
        System.out.println("Кот " + name + " мяукал " + cat.getMeowCount() + " раз(а).");
    }

    // === Задание 3: Список ===
    private static void runListTask() {
        System.out.println("\n--- Задание 3: Список ---");
        System.out.print("Введите элементы списка через пробел: ");
        SCANNER.nextLine(); // очистка буфера
        String input = SCANNER.nextLine();
        List<String> list = new ArrayList<>(Arrays.asList(input.split("\\s+")));

        List<String> result = CollectionUtils.removeConsecutiveDuplicates(list);
        System.out.println("Результат: " + result);
    }

    // === Задание 4: Сметана ===
    private static void runSourCreamTask() {
        System.out.println("\n--- Задание 4: Сметана ---");
        System.out.print("Введите путь к файлу с данными (например, data/sourcream.txt): ");
        String path = SCANNER.next();
        try {
            String result = SourCreamMonitor.analyzeFile(new File(path));
            System.out.println("Результат (количество магазинов с минимальными ценами): " + result);
        } catch (FileNotFoundException e) {
            System.out.println("Ошибка чтения файла: " + e.getMessage());
        }
    }

    // === Задание 5: Текст ===
    private static void runDigitFinderTask() {
        System.out.println("\n--- Задание 5: Текст ---");
        System.out.print("Введите путь к файлу с текстом (например, data/text.txt): ");
        String path = SCANNER.next();
        try {
            String text = new String(java.nio.file.Files.readAllBytes(new File(path).toPath()));
            Set<Character> digits = DigitFinder.findDigits(text);
            System.out.println("Цифры, встречающиеся в тексте: " + digits);
        } catch (Exception e) {
            System.out.println("Ошибка чтения файла: " + e.getMessage());
        }
    }

    // === Задание 6: Очередь ===
    private static void runQueueTask() {
        System.out.println("\n--- Задание 6: Очередь ---");
        System.out.print("Введите элементы очереди через пробел: ");
        SCANNER.nextLine();
        String input = SCANNER.nextLine();
        Queue<String> queue = new LinkedList<>(Arrays.asList(input.split("\\s+")));

        boolean hasEqual = QueueUtils.hasCircularEqualNeighbor(queue);
        System.out.println(hasEqual
                ? "Есть хотя бы одна пара одинаковых соседних элементов (по кругу)."
                : "Нет одинаковых соседних элементов.");
    }

    // === Задание 7.1: Геометрия ===
    private static void runGeometryTask() {
        System.out.println("\n--- Задание 7.1: Геометрия ---");
        System.out.println("Введите точки (пример: 1 2, 3 -4, 5 6): ");
        SCANNER.nextLine();
        String input = SCANNER.nextLine();

        List<Point> points = Arrays.stream(input.split(","))
                .map(String::trim)
                .map(s -> s.split("\\s+"))
                .filter(arr -> arr.length == 2)
                .map(arr -> new Point(Double.parseDouble(arr[0]), Double.parseDouble(arr[1])))
                .collect(Collectors.toList());

        Polyline polyline = Polyline.fromPoints(points);
        System.out.println("Ломаная: " + polyline);
    }

    // === Задание 7.2: Люди ===
    private static void runPeopleTask() {
        System.out.println("\n--- Задание 7.2: Люди ---");
        System.out.print("Введите путь к файлу с людьми (например, data/people.txt): ");
        String path = SCANNER.next();
        try {
            Map<Integer, List<String>> groups = PeopleGrouper.groupPeopleByNumber(new File(path));
            System.out.println("Результат группировки: " + groups);
        } catch (FileNotFoundException e) {
            System.out.println("Ошибка чтения файла: " + e.getMessage());
        }
    }

    // === Вспомогательные методы ===
    private static int readInt() {
        while (true) {
            try {
                return Integer.parseInt(SCANNER.next());
            } catch (NumberFormatException e) {
                System.out.print("Введите корректное целое число: ");
            }
        }
    }

    private static int readNonZeroInt() {
        while (true) {
            int value = readInt();
            if (value != 0) return value;
            System.out.print("Знаменатель не может быть равен 0, попробуйте снова: ");
        }
    }
}
