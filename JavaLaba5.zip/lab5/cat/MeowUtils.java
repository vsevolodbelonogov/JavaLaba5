package lab5.cat;

public class MeowUtils {

    /** Вызывает метод meow() у всех мяукающих. */
    public static void makeAllMeow(Meowable[] meowers) {
        for (Meowable m : meowers) {
            m.meow();
        }
    }
}
