package lab5.cat;

public interface Meowable {
    void meow();
}
