package lab5.fraction;

/**
 * Класс Дробь — хранит числитель и знаменатель, корректно обрабатывает отрицательные значения
 * и кэширует вычисленное вещественное значение.
 */
public class Fraction implements RealValueMutable {
    private int numerator;
    private int denominator;
    private Double cachedValue = null;

    public Fraction(int numerator, int denominator) {
        setNumerator(numerator);
        setDenominator(denominator);
    }

    @Override
    public void setNumerator(int numerator) {
        this.numerator = numerator;
        cachedValue = null;
    }

    @Override
    public void setDenominator(int denominator) {
        if (denominator == 0) {
            throw new IllegalArgumentException("Знаменатель не может быть равен нулю.");
        }
        if (denominator < 0) {
            denominator = -denominator;
            numerator = -numerator;
        }
        this.denominator = denominator;
        cachedValue = null;
    }

    @Override
    public double getRealValue() {
        if (cachedValue == null) {
            cachedValue = (double) numerator / denominator;
        }
        return cachedValue;
    }

    @Override
    public String toString() {
        return numerator + "/" + denominator;
    }

    @Override
    public boolean equals(Object o) {
        if (!(o instanceof Fraction)) return false;
        Fraction f = (Fraction) o;
        return this.numerator == f.numerator && this.denominator == f.denominator;
    }

    @Override
    public int hashCode() {
        return numerator * 31 + denominator;
    }
}
