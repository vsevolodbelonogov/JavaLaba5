package lab5.fraction;

/** Интерфейс для работы с дробями. */
public interface RealValueMutable {
    double getRealValue();
    void setNumerator(int numerator);
    void setDenominator(int denominator);
}
