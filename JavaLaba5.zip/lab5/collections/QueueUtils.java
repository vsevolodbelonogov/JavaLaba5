package lab5.collections;

import java.util.LinkedList;
import java.util.Queue;

public class QueueUtils {

    /** Проверяет, есть ли в очереди элемент, равный следующему по кругу. */
    public static <T> boolean hasCircularEqualNeighbor(Queue<T> queue) {
        if (queue.isEmpty()) return false;

        LinkedList<T> list = new LinkedList<>(queue);
        for (int i = 0; i < list.size(); i++) {
            T current = list.get(i);
            T next = list.get((i + 1) % list.size());
            if (current.equals(next)) return true;
        }
        return false;
    }
}
