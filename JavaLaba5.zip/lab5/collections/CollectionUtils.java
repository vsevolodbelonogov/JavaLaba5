package lab5.collections;

import java.util.*;

/**
 * Убирает подряд идущие одинаковые элементы из списка.
 */
public class CollectionUtils {

    public static <T> List<T> removeConsecutiveDuplicates(List<T> list) {
        if (list.isEmpty()) return Collections.emptyList();

        List<T> result = new ArrayList<>();
        T prev = null;

        for (T item : list) {
            if (!item.equals(prev)) {
                result.add(item);
            }
            prev = item;
        }
        return result;
    }
}
