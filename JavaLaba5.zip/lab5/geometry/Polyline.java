package lab5.geometry;

import java.util.*;
import java.util.stream.Collectors;

public class Polyline {
    private final List<Point> points;

    public Polyline(List<Point> points) {
        this.points = new ArrayList<>(points);
    }

    @Override
    public String toString() {
        return "Линия " + points;
    }

    public static Polyline fromPoints(List<Point> inputPoints) {
        List<Point> filtered = inputPoints.stream()
                .distinct()
                .map(p -> new Point(p.getX(), Math.abs(p.getY())))
                .sorted(Comparator.comparingDouble(Point::getX))
                .collect(Collectors.toList());
        return new Polyline(filtered);
    }
}
