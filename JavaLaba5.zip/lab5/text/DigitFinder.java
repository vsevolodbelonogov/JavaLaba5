package lab5.text;

import java.util.HashSet;
import java.util.Set;

public class DigitFinder {

    public static Set<Character> findDigits(String text) {
        Set<Character> digits = new HashSet<>();
        for (char c : text.toCharArray()) {
            if (Character.isDigit(c)) {
                digits.add(c);
            }
        }
        return digits;
    }
}
