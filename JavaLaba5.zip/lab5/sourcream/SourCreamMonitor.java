package lab5.sourcream;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

public class SourCreamMonitor {

    public static String analyzeFile(File file) throws FileNotFoundException {
        Scanner scanner = new Scanner(file);

        Map<Integer, Integer> minPrice = new HashMap<>();
        Map<Integer, Integer> count = new HashMap<>();

        while (scanner.hasNext()) {
            String firm = scanner.next();
            String street = scanner.next();
            int fat = scanner.nextInt();
            int price = scanner.nextInt();

            if (!minPrice.containsKey(fat) || price < minPrice.get(fat)) {
                minPrice.put(fat, price);
                count.put(fat, 1);
            } else if (price == minPrice.get(fat)) {
                count.put(fat, count.get(fat) + 1);
            }
        }
        scanner.close();

        int c15 = count.getOrDefault(15, 0);
        int c20 = count.getOrDefault(20, 0);
        int c25 = count.getOrDefault(25, 0);

        return c15 + " " + c20 + " " + c25;
    }
}
